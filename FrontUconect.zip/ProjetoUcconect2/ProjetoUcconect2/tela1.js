function login() {
    alert("Você clicou em Login!");
  }
  
  function cadastro() {
    alert("Você clicou em Cadastro!");
  }