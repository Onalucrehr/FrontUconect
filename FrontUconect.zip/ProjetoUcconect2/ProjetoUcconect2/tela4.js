document.querySelector('.btn-back').addEventListener('click', () => {
    alert('Voltando para a página anterior...');
});

document.querySelector('.btn-next').addEventListener('click', (event) => {
    event.preventDefault();
    alert('Cadastro finalizado com sucesso!');
});
