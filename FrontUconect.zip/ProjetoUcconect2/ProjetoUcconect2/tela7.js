// Função para lidar com o login
function login() {
    // Obter os valores dos campos
    const matricula = document.getElementById('matricula').value;
    const senha = document.getElementById('senha').value;
  
    // Validar os campos
    if (matricula === '' || senha === '') {
      alert('Por favor, preencha todos os campos.');
      return;
    }
  
    // Aqui você pode adicionar a lógica de login (por exemplo, verificar se as credenciais estão corretas)
    // Por enquanto, exibe um alerta de sucesso
    alert(`Login realizado com sucesso! Matrícula: ${matricula}`);
    
    // Redirecionar ou realizar outra ação (exemplo de redirecionamento)
    // window.location.href = 'pagina-principal.html';  // redireciona para outra página
  }
  
  // Função para voltar à página anterior
  function voltar() {
    window.history.back();  // Volta à página anterior
  }
  

  // Função para verificar os campos e habilitar o botão "Entrar"
function verificarCampos() {
  const matricula = document.getElementById('matricula').value;
  const senha = document.getElementById('senha').value;
  const btnEntrar = document.getElementById('btnEntrar');

  // Verifica se os campos de matrícula e senha estão preenchidos
  if (matricula !== '' && senha !== '') {
      btnEntrar.disabled = false;  // Habilita o botão "Entrar"
  } else {
      btnEntrar.disabled = true;   // Desabilita o botão "Entrar"
  }
}

// Adiciona o evento de "input" aos campos para chamar a função de verificação sempre que o usuário digitar
document.getElementById('matricula').addEventListener('input', verificarCampos);
document.getElementById('senha').addEventListener('input', verificarCampos);
