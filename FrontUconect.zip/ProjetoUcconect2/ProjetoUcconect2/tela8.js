// Alterna entre abas
function changeTab(tabName) {
  document.querySelectorAll('.feed, .chat-container').forEach(el => {
    el.style.display = 'none';
  });

  document.querySelectorAll('.tab').forEach(tab => {
    tab.classList.remove('active');
  });

  document.getElementById(tabName).style.display = 'block';
  document.querySelector(`.tab[onclick="changeTab('${tabName}')"]`).classList.add('active');
}

// Dropdown do perfil
function toggleDropdown() {
  const dropdown = document.getElementById('dropdown-menu');
  dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

// Carrega aba Feed por padrão
window.onload = () => {
  changeTab('feed');
};
