document.addEventListener("DOMContentLoaded", () => {
    const alunoBtn = document.querySelectorAll(".btn-back")[0];
    const professorBtn = document.querySelectorAll(".btn-back")[1];
    const coordenacaoBtn = document.querySelector(".btn-next");
  
    alunoBtn.addEventListener("click", () => {
      console.log("Cadastro como Aluno");
      // window.location.href = "aluno.html";
    });
  
    professorBtn.addEventListener("click", () => {
      console.log("Cadastro como Professor");
      // window.location.href = "professor.html";
    });
  
    coordenacaoBtn.addEventListener("click", () => {
      console.log("Cadastro como Coordenação");
      // window.location.href = "coordenacao.html";
    });
  });