document.addEventListener("DOMContentLoaded", () => {
    const alunoBtn = document.querySelectorAll(".btn-back")[0];
    const professorBtn = document.querySelectorAll(".btn-back")[1];
    const coordenacaoBtn = document.querySelector(".btn-next");
  
    alunoBtn.addEventListener("click", () => {
      console.log("Login como Aluno");
      // window.location.href = "aluno.html";
    });
  
    professorBtn.addEventListener("click", () => {
      console.log("Login como Professor");
      // window.location.href = "professor.html";
    });
  
    coordenacaoBtn.addEventListener("click", () => {
      console.log("Login como Coordenação");
      // window.location.href = "coordenacao.html";
    });
  });