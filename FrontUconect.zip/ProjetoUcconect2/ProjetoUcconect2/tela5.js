function goBack() {
    window.location.href = "tela01.html"; // Altere para o nome do arquivo da tela 01
  }
  