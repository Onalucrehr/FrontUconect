// ================= TABS / NAVEGAÇÃO =================

function changeTab(tabName) {
  if (tabName === 'calendario') {
    gerarCalendario();
  }
  document.querySelectorAll('.feed').forEach(function (section) {
    section.style.display = 'none';
  });
  document.querySelectorAll('.tab').forEach(function (tab) {
    tab.classList.remove('active');
  });
  document.querySelectorAll('.sidebar nav ul li').forEach(function (item) {
    item.classList.remove('active');
  });
  const selectedSection = document.getElementById(tabName);
  if (selectedSection) {
    selectedSection.style.display = 'block';
  }
  const tabButton = document.querySelector(`.tab[onclick="changeTab('${tabName}')"]`);
  if (tabButton) {
    tabButton.classList.add('active');
  }
  const sideItem = document.querySelector(`.sidebar nav ul li[onclick="changeTab('${tabName}')"]`);
  if (sideItem) {
    sideItem.classList.add('active');
  }
}
// Menu
function toggleDropdown() {
  const dropdown = document.getElementById('dropdown-menu');
  dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}
window.onload = function () {
  changeTab('comunicados');
};

// calendario
let mesAtual = new Date().getMonth();
let anoAtual = new Date().getFullYear();

const nomesMeses = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
];

const feriados = {
  // Feriados Nacionais
  "2025-01-01": "Confraternização Universal",
  "2025-04-18": "Paixão de Cristo",
  "2025-04-21": "Tiradentes",
  "2025-05-01": "Dia do Trabalho",
  "2025-09-07": "Independência do Brasil",
  "2025-10-12": "Nossa Senhora Aparecida",
  "2025-11-02": "Finados",
  "2025-11-15": "Proclamação da República",
  "2025-11-20": "Dia da Consciência Negra",
  "2025-12-25": "Natal",

  // Feriados Estaduais (Distrito Federal)
  "2025-04-21": "Aniversário de Brasília",
  "2025-11-30": "Dia do Evangélico",

  // Pontos Facultativos no DF
  "2025-03-03": "Carnaval (Ponto Facultativo)",
  "2025-03-04": "Carnaval (Ponto Facultativo)",
  "2025-03-05": "Quarta-feira de Cinzas (até as 14h)",
  "2025-06-19": "Corpus Christi",
  "2025-06-20": "Ponto Facultativo",
  "2025-10-28": "Dia do Servidor Público",
  "2025-12-24": "Véspera de Natal (após as 14h)",
  "2025-12-31": "Véspera de Ano Novo (após as 14h)"
};

function mudarMes(delta) {
  mesAtual += delta;
  if (mesAtual > 11) {
    mesAtual = 0;
    anoAtual++;
  } else if (mesAtual < 0) {
    mesAtual = 11;
    anoAtual--;
  }
  gerarCalendario();
}

function gerarCalendario() {
  const diasContainer = document.getElementById("dias");
  const tituloMes = document.getElementById("tituloMes");

  if (!diasContainer || !tituloMes) return;

  diasContainer.innerHTML = "";
  tituloMes.textContent = `${nomesMeses[mesAtual]} ${anoAtual}`;

  const primeiroDia = new Date(anoAtual, mesAtual, 1);
  const ultimoDia = new Date(anoAtual, mesAtual + 1, 0);
  const diaSemana = primeiroDia.getDay();

  let linha = document.createElement("tr");

  for (let i = 0; i < diaSemana; i++) {
    linha.appendChild(document.createElement("td"));
  }

  for (let dia = 1; dia <= ultimoDia.getDate(); dia++) {
    if (linha.children.length === 7) {
      diasContainer.appendChild(linha);
      linha = document.createElement("tr");
    }

    const celula = document.createElement("td");
    celula.textContent = dia;

    const dataStr = `${anoAtual}-${String(mesAtual + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;

    if (feriados[dataStr]) {
  celula.title = feriados[dataStr];

  if (feriados[dataStr].includes("Ponto Facultativo") || feriados[dataStr].includes("Cinzas")) {
    celula.classList.add("ponto-facultativo");
  } else if (feriados[dataStr].includes("Aniversário de Brasília") || feriados[dataStr].includes("Evangélico")) {
    celula.classList.add("feriado-estadual");
  } else {
    celula.classList.add("feriado-nacional");
  }
}
    const hoje = new Date();
    if (
      dia === hoje.getDate() &&
      mesAtual === hoje.getMonth() &&
      anoAtual === hoje.getFullYear()
    ) {
      celula.classList.add("hoje");
    }
    celula.onclick = () => abrirPopup(dia);
    linha.appendChild(celula);
  }
  diasContainer.appendChild(linha);
}

function abrirPopup(dia) {
  const popup = document.getElementById("popup");
  const titulo = document.getElementById("tituloPopupDia");
  const comentarioInput = document.getElementById("comentarioDia");

  const dataCompleta = `${anoAtual}-${String(mesAtual + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;

  if (popup && titulo && comentarioInput) {
    const feriadoTexto = feriados[dataCompleta] ? ` - ${feriados[dataCompleta]}` : "";
    titulo.textContent = `Dia ${String(dia).padStart(2, "0")}/${String(mesAtual + 1).padStart(2, "0")}/${anoAtual}${feriadoTexto}`;
    comentarioInput.value = localStorage.getItem(`evento-${dataCompleta}`) || "";
    comentarioInput.setAttribute("data-dia", dataCompleta);
    popup.classList.remove("hidden");
  }
}

function fecharPopup() {
  const popup = document.getElementById("popup");
  if (popup) {
    popup.classList.add("hidden");
  }
}

function salvarComentario() {
  const comentarioInput = document.getElementById("comentarioDia");
  const data = comentarioInput.getAttribute("data-dia");
  const texto = comentarioInput.value.trim();

  if (data) {
    if (texto) {
      localStorage.setItem(`evento-${data}`, texto);
    } else {
      localStorage.removeItem(`evento-${data}`);
    }
    fecharPopup();
    atualizarAgenda();
  }
}

function excluirComentario() {
  const comentarioInput = document.getElementById("comentarioDia");
  const data = comentarioInput.getAttribute("data-dia");

  if (data) {
    localStorage.removeItem(`evento-${data}`);
    fecharPopup();
    atualizarAgenda();
  }
}

function atualizarAgenda() {
  const lista = document.getElementById("listaAgenda");
  lista.innerHTML = "";
  const chaves = Object.keys(localStorage).filter(k => k.startsWith("evento-"));

  if (chaves.length === 0) {
    lista.innerHTML = "<li>Nenhum evento salvo.</li>";
    return;
  }

  chaves.sort().forEach(chave => {
    const texto = localStorage.getItem(chave);
    const data = chave.replace("evento-", "").split("-").reverse().join("/");
    const li = document.createElement("li");
    li.textContent = `${data}: ${texto}`;
    lista.appendChild(li);
  });
}
function toggleAgenda() {
  const lista = document.getElementById("listaAgenda");
  const botao = document.getElementById("toggleAgenda");
  if (!lista || !botao) return; // segurança

  if (lista.style.display === "none" || lista.style.display === "") {
    lista.style.display = "block";
    botao.textContent = "<";
  } else {
    lista.style.display = "none";
    botao.textContent = ">";
  }
}
document.addEventListener("DOMContentLoaded", () => {
  changeTab('comunicados'); 
  atualizarAgenda();

  const lista = document.getElementById("listaAgenda");
  if (lista) {
    lista.style.display = "none";
  }
});
let contatoAtivo = null;

function adicionarContato() {
  const nome = prompt("Digite o nome do novo contato:");
  if (!nome) return;
  const contatos = JSON.parse(localStorage.getItem("contatos")) || [];
  if (contatos.includes(nome)) return alert("Contato já existe!");
  contatos.push(nome);
  localStorage.setItem("contatos", JSON.stringify(contatos));
  renderizarContato(nome);
}

function renderizarContato(nome) {
  const novoContato = document.createElement("li");
  novoContato.className = "contato-item";

  const nomeSpan = document.createElement("span");
  nomeSpan.textContent = nome;
  nomeSpan.onclick = () => abrirConversa(nome);

  const mensagens = JSON.parse(localStorage.getItem("mensagens_" + nome)) || [];
  const ultima = mensagens.length > 0 ? mensagens[mensagens.length - 1].texto.slice(0, 25) + "..." : "";
  const preview = document.createElement("small");
  preview.textContent = ultima;
  preview.style.display = "block";
  preview.style.fontSize = "12px";

  const botaoExcluir = document.createElement("button");
  botaoExcluir.textContent = "X";
  botaoExcluir.className = "botao-excluir";
  botaoExcluir.onclick = (e) => {
    e.stopPropagation();
    excluirContato(nome, novoContato);
  };

  nomeSpan.appendChild(preview);
  novoContato.appendChild(nomeSpan);
  if (!["Coordenação UCB", "Prof. Flávia", "Secretaria Acadêmica", "Biblioteca", "Prof. Luciano"].includes(nome)) {
    novoContato.appendChild(botaoExcluir);
  }
  document.getElementById("contact-list").appendChild(novoContato);
}

function excluirContato(nome, elemento) {
  let contatos = JSON.parse(localStorage.getItem("contatos")) || [];
  contatos = contatos.filter(c => c !== nome);
  localStorage.setItem("contatos", JSON.stringify(contatos));
  elemento.remove();
  if (contatoAtivo === nome) {
    contatoAtivo = null;
    document.getElementById("nomeContatoAtivo").textContent = "Selecione um contato";
    document.getElementById("janelaMensagens").innerHTML = "";
  }
}
function filtrarContatos() {
  const termo = document.getElementById("buscaContato").value.toLowerCase();
  document.querySelectorAll("#contact-list li").forEach(li => {
    li.style.display = li.textContent.toLowerCase().includes(termo) ? "flex" : "none";
  });
}

function abrirConversa(nome) {
  contatoAtivo = nome;
  document.getElementById("nomeContatoAtivo").textContent = nome;
  const mensagens = JSON.parse(localStorage.getItem("mensagens_" + nome)) || [];
  const janela = document.getElementById("janelaMensagens");
  janela.innerHTML = "";

  mensagens.forEach((m, index) => {
    const div = document.createElement("div");
    div.className = "mensagem " + m.remetente;

    const textoSpan = document.createElement("span");
    textoSpan.textContent = `${m.texto} (${m.horario})`;
    div.appendChild(textoSpan);

    if (m.remetente === "usuario") {
      const btnApagar = document.createElement("button");
      btnApagar.textContent = "🗑";
      btnApagar.className = "botao-excluir";
      btnApagar.style.marginLeft = "10px";
      btnApagar.onclick = () => apagarMensagem(index);
      div.appendChild(btnApagar);
    }
    janela.appendChild(div);

    if (m.remetente === "usuario") {
    const botaoCalendario = document.createElement("button");
    botaoCalendario.textContent = "📅";
    botaoCalendario.style.marginLeft = "10px";
    botaoCalendario.onclick = () => adicionarAoCalendario(m.texto);
    div.appendChild(botaoCalendario);
}
  });
  janela.scrollTop = janela.scrollHeight;
}

function excluirComentario() {
  const comentarioInput = document.getElementById("comentarioDia");
  const data = comentarioInput.getAttribute("data-dia");
  localStorage.removeItem(`evento-${data}`);
  fecharPopup();
  atualizarAgenda();
}

function adicionarAoCalendario(texto) {
  const data = prompt("Informe a data para o evento (YYYY-MM-DD):");
  if (!data) return;
  localStorage.setItem(`evento-${data}`, texto);
  alert("Evento adicionado ao calendário!");
}

function enviarMensagem() {
  const input = document.getElementById("inputMensagem");
  const texto = input.value.trim();
  if (!texto || !contatoAtivo) return;

  const agora = new Date();
  const horario = agora.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const mensagens = JSON.parse(localStorage.getItem("mensagens_" + contatoAtivo)) || [];
  mensagens.push({ remetente: "usuario", texto, horario });
  localStorage.setItem("mensagens_" + contatoAtivo, JSON.stringify(mensagens));

  abrirConversa(contatoAtivo);
  input.value = "";

  setTimeout(() => responderBot(contatoAtivo), 800);
}
function responderBot(nome) {
  const mensagens = JSON.parse(localStorage.getItem("mensagens_" + nome)) || [];
  const respostas = {
    "horário": "Funcionamos de segunda a sexta, das 8h às 18h.",
    "prova": "A próxima prova está agendada no calendário.",
    "nota": "As notas serão lançadas até o final do mês.",
    "olá": "Olá! Como posso ajudar?"
  };
  const ultimaMensagem = mensagens[mensagens.length - 1].texto.toLowerCase();
  let resposta = "Recebido!";

  for (const chave in respostas) {
    if (ultimaMensagem.includes(chave)) {
      resposta = respostas[chave];
      break;
    }
  }

  mensagens.push({ remetente: "bot", texto: resposta });
  localStorage.setItem("mensagens_" + nome, JSON.stringify(mensagens));
  if (contatoAtivo === nome) abrirConversa(nome);
}

function apagarMensagem(index) {
  const mensagens = JSON.parse(localStorage.getItem("mensagens_" + contatoAtivo)) || [];
  mensagens.splice(index, 1);
  localStorage.setItem("mensagens_" + contatoAtivo, JSON.stringify(mensagens));
  abrirConversa(contatoAtivo);
}
function apagarConversa() {
  if (!contatoAtivo) return;

  const confirmacao = confirm(`Tem certeza que deseja apagar toda a conversa com "${contatoAtivo}"?`);
  if (confirmacao) {
    localStorage.removeItem("mensagens_" + contatoAtivo);
    abrirConversa(contatoAtivo);
  }
}

function anexarArquivo(input) {
  if (input.files.length > 0) {
    const file = input.files[0];
    const mensagem = {
      remetente: "usuario",
      texto: `[Arquivo] ${file.name}`
    };
    salvarMensagem(contatoAtivo, mensagem);
    abrirConversa(contatoAtivo);
  }
}

function abrirEmojiPicker() {
  const emoji = prompt("Digite um emoji ou copie e cole aqui:");
  if (emoji) {
    const input = document.getElementById("inputMensagem");
    input.value += emoji;
    input.focus();
  }
}
if (m.remetente === "usuario") {
  const fixar = document.createElement("button");
  fixar.textContent = "📌";
  fixar.style.marginLeft = "10px";
  fixar.onclick = () => {
    localStorage.setItem("fixada_" + contatoAtivo, m.texto);
    alert("Mensagem fixada!");
  };
  div.appendChild(fixar);
}
const fixada = localStorage.getItem("fixada_" + contatoAtivo);
if (fixada) {
  const destaque = document.createElement("div");
  destaque.className = "mensagem bot";
  destaque.textContent = "📌 " + fixada;
  destaque.style.backgroundColor = "#ffe082";
  destaque.style.fontWeight = "bold";
  janela.appendChild(destaque);
}
